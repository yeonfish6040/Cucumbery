package com.jho5245.cucumbery.util.storage.data;

import com.jho5245.cucumbery.Cucumbery;
import org.bukkit.NamespacedKey;

public class CucumberyNamespacedKey
{
  public static final NamespacedKey TMI_RARITY = new NamespacedKey(Cucumbery.getPlugin(), "rarity");
}
