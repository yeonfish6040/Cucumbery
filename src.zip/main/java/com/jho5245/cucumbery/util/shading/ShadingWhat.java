package com.jho5245.cucumbery.util.shading;

public class ShadingWhat
{
  public ShadingWhat()
  {
    System.out.println("Shading!");
  }
}
