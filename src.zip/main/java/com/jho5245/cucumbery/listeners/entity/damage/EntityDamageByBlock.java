package com.jho5245.cucumbery.listeners.entity.damage;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByBlockEvent;

public class EntityDamageByBlock implements Listener
{
  @EventHandler
  public void onEntityDamageByBlock(EntityDamageByBlockEvent event)
  {
  }
}
