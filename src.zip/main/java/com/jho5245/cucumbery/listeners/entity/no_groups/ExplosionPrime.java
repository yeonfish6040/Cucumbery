package com.jho5245.cucumbery.listeners.entity.no_groups;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ExplosionPrimeEvent;

public class ExplosionPrime implements Listener
{
	@EventHandler
	public void onExplosionPrime(ExplosionPrimeEvent event)
	{
		
	}
}
