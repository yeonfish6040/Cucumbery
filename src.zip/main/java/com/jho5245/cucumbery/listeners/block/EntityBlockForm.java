package com.jho5245.cucumbery.listeners.block;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.EntityBlockFormEvent;

public class EntityBlockForm implements Listener
{
	@EventHandler
	public void onEntityBlockForm(EntityBlockFormEvent event)
	{
		
	}
}
