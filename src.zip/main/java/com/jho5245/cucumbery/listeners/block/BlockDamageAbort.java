package com.jho5245.cucumbery.listeners.block;

import com.comphenix.protocol.PacketType.Play;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.reflect.StructureModifier;
import com.jho5245.cucumbery.Cucumbery;
import com.jho5245.cucumbery.custom.customeffect.CustomEffectManager;
import com.jho5245.cucumbery.custom.customeffect.CustomEffectScheduler;
import com.jho5245.cucumbery.custom.customeffect.type.CustomEffectTypeCustomMining;
import com.jho5245.cucumbery.util.addons.ProtocolLibManager;
import com.jho5245.cucumbery.util.no_groups.Method;
import com.jho5245.cucumbery.util.storage.data.Variable;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockDamageAbortEvent;

import java.lang.reflect.InvocationTargetException;
import java.util.UUID;

public class BlockDamageAbort implements Listener
{
  @EventHandler
  public void onBlockDamageAbort(BlockDamageAbortEvent event)
  {
    Player player = event.getPlayer();
    UUID uuid = player.getUniqueId();
    if (CustomEffectManager.hasEffect(player, CustomEffectTypeCustomMining.CUSTOM_MINING_SPEED_MODE))
    {
      Variable.customMiningProgress.put(uuid, 0f);
      if (Cucumbery.using_ProtocolLib)
      {
        ProtocolManager protocolManager = ProtocolLibrary.getProtocolManager();
        PacketContainer packetContainer = protocolManager.createPacket(Play.Server.BLOCK_BREAK_ANIMATION);
        StructureModifier<Object> modifier = packetContainer.getModifier();
        modifier.write(0, CustomEffectScheduler.blockBreakKey.getOrDefault(uuid, Method.random(1, Integer.MAX_VALUE)));
        modifier.write(1, ProtocolLibManager.getBlockPosition(0, 0, 0));
        modifier.write(2, 0);
        Bukkit.getOnlinePlayers().forEach(online ->
        {
          if (online.getWorld().getName().equals(player.getWorld().getName()))
          {
            try
            {
              protocolManager.sendServerPacket(online, packetContainer);
            }
            catch (InvocationTargetException e)
            {
              e.printStackTrace();
            }
          }
        });
      }
      else
      {
        Bukkit.getScheduler().runTaskLater(Cucumbery.getPlugin(), () ->
                player.sendBlockDamage(new Location(Bukkit.getWorlds().get(0), 0, 0, 0), 0f), 1L);

      }
      CustomEffectManager.removeEffect(player, CustomEffectTypeCustomMining.CUSTOM_MINING_SPEED_MODE_PROGRESS);
    }
  }
}
