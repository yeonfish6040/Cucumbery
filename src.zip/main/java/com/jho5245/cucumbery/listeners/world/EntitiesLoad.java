package com.jho5245.cucumbery.listeners.world;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.jetbrains.annotations.NotNull;

public class EntitiesLoad implements Listener
{
  @EventHandler
  public void onEntitiesLoad(@NotNull EntitiesLoadEvent event)
  {

  }
}
