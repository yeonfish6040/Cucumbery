package com.jho5245.cucumbery.listeners.player.no_groups;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;

public class PlayerPreLogin implements Listener
{
  @EventHandler
  public void onPlayerPreLogin(AsyncPlayerPreLoginEvent event)
  {

  }
}
