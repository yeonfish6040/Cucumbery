package com.jho5245.cucumbery.listeners.player.no_groups;

import com.destroystokyo.paper.event.player.PlayerArmorChangeEvent;
import com.jho5245.cucumbery.Cucumbery;
import com.jho5245.cucumbery.util.no_groups.Method;
import com.jho5245.cucumbery.util.storage.data.CustomMaterial;
import com.jho5245.cucumbery.util.storage.no_groups.ItemStackUtil;
import de.tr7zw.changeme.nbtapi.NBTItem;
import org.bukkit.Bukkit;
import org.bukkit.entity.AbstractSkeleton;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public class PlayerArmorChange implements Listener
{
  @EventHandler
  public void onPLayerArmorChange(PlayerArmorChangeEvent event)
  {
    Player player = event.getPlayer();
    ItemStack oldItem = event.getOldItem(), newItem = event.getNewItem();
    if (ItemStackUtil.itemExists(oldItem) && new NBTItem(oldItem).hasKey("id") || ItemStackUtil.itemExists(newItem) && new NBTItem(newItem).hasKey("id"))
    {
      Bukkit.getScheduler().runTaskLater(Cucumbery.getPlugin(), () -> Method.updateInventory(player), 0L);
    }
    this.sansArmor(event);
  }

  private void sansArmor(PlayerArmorChangeEvent event)
  {
    Player player = event.getPlayer();
    Bukkit.getScheduler().runTaskLater(Cucumbery.getPlugin(), () ->
    {
      PlayerInventory playerInventory = player.getInventory();
      ItemStack helmet = playerInventory.getHelmet(), chestplate = playerInventory.getChestplate(), leggings = playerInventory.getLeggings(), boots = playerInventory.getBoots();
      if (CustomMaterial.itemStackOf(helmet) == CustomMaterial.SANS_HELMET &&
              CustomMaterial.itemStackOf(chestplate) == CustomMaterial.SANS_CHESTPLATE &&
              CustomMaterial.itemStackOf(leggings) == CustomMaterial.SANS_LEGGINGS &&
              CustomMaterial.itemStackOf(boots) == CustomMaterial.SANS_BOOTS)
      {
        player.getNearbyEntities(50, 50, 50).forEach(e -> {
          if (e instanceof AbstractSkeleton abstractSkeleton && abstractSkeleton.getTarget() == player)
          {
            abstractSkeleton.setTarget(null);
          }
        });
      }
    }, 0L);
  }
}
