package com.jho5245.cucumbery.listeners.player.no_groups;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerExpChangeEvent;

public class PlayerExpChange implements Listener
{
  @EventHandler
  public void onplayerExpChange(PlayerExpChangeEvent event)
  {
  }
}
