package com.jho5245.cucumbery.custom;

public record CombatInfo(double originalDamage, double damage, double bonusDamage, double damageMultiplier, double finalDamageMultiplier)
{
}
