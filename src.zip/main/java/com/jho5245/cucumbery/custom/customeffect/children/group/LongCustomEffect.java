package com.jho5245.cucumbery.custom.customeffect.children.group;

public interface LongCustomEffect
{
  long getLong();

  void setLong(long l);
}
