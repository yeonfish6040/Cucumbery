package com.jho5245.cucumbery.custom.customeffect.children.group;

import org.jetbrains.annotations.NotNull;

public interface StringCustomEffect
{
  @NotNull String getString();

  void setString(@NotNull String s);
}
