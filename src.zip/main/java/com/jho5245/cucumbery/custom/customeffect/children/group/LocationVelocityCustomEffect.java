package com.jho5245.cucumbery.custom.customeffect.children.group;

public interface LocationVelocityCustomEffect extends LocationCustomEffect, VelocityCustomEffect
{
}
